import { useCallback, useEffect, useState } from 'react';
import { ExamPaperWorkspace } from './components/ExamPaperWorkspace';
import { TopToolbar } from './components/TopToolbar';
import { ExamDocument, ExamHeaderData, QuestionSectionType } from './types/exam';
import { createDefaultExam, createId } from './utils/defaultExam';
import { exportExamToDocx } from './utils/exportDocx';
import { exportExamToPdf } from './utils/exportPdf';
import {
  addQuestionToSection,
  deleteQuestionFromSection,
  enableAutoScore,
  updateQuestionScore,
  updateSectionTargetTotal,
} from './utils/scoring';

const STORAGE_KEY = 'english_exam_paper_builder_v1';

function loadInitialExam(): ExamDocument {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultExam();
    const parsed = JSON.parse(raw) as ExamDocument;
    if (
      parsed &&
      parsed.header &&
      Array.isArray(parsed.sectionOrder) &&
      parsed.sections?.zhToEn &&
      parsed.sections?.enToZh
    ) {
      return parsed;
    }
  } catch {
    // Fallback to default on invalid stored JSON
  }
  return createDefaultExam();
}

export default function App() {
  const [exam, setExam] = useState<ExamDocument>(loadInitialExam);
  const [focusedQuestionId, setFocusedQuestionId] = useState<string | null>(null);
  const [pageCount, setPageCount] = useState<number>(1);
  const [isDownloadingStandalone, setIsDownloadingStandalone] = useState(false);
  const [isExportingWord, setIsExportingWord] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [exportError, setExportError] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(exam));
    } catch {
      // Ignore storage quota errors
    }
  }, [exam]);

  const handleHeaderChange = useCallback((header: ExamHeaderData) => {
    setExam((prev) => ({ ...prev, header }));
  }, []);

  const handleAddInfoField = useCallback(() => {
    setExam((prev) => ({
      ...prev,
      header: {
        ...prev.header,
        infoFields: [
          ...prev.header.infoFields,
          { id: createId('info'), text: '科別：________' },
        ],
      },
    }));
  }, []);

  const handleSectionOrderChange = useCallback((sectionOrder: QuestionSectionType[]) => {
    setExam((prev) => ({ ...prev, sectionOrder }));
  }, []);

  const handleSectionTitleChange = useCallback(
    (sectionId: QuestionSectionType, title: string) => {
      setExam((prev) => ({
        ...prev,
        sections: {
          ...prev.sections,
          [sectionId]: {
            ...prev.sections[sectionId],
            title,
          },
        },
      }));
    },
    []
  );

  const handleSectionTargetTotalChange = useCallback(
    (sectionId: QuestionSectionType, total: number) => {
      setExam((prev) => ({
        ...prev,
        sections: {
          ...prev.sections,
          [sectionId]: updateSectionTargetTotal(prev.sections[sectionId], total),
        },
      }));
    },
    []
  );

  const handleEnableAutoScore = useCallback((sectionId: QuestionSectionType) => {
    setExam((prev) => ({
      ...prev,
      sections: {
        ...prev.sections,
        [sectionId]: enableAutoScore(prev.sections[sectionId]),
      },
    }));
  }, []);

  const handleAddQuestion = useCallback((sectionId: QuestionSectionType) => {
    const newId = createId(sectionId === 'zhToEn' ? 'zh' : 'en');
    setExam((prev) => ({
      ...prev,
      sections: {
        ...prev.sections,
        [sectionId]: addQuestionToSection(prev.sections[sectionId], newId, ''),
      },
    }));
    setFocusedQuestionId(newId);
  }, []);

  const handleQuestionTextChange = useCallback(
    (sectionId: QuestionSectionType, questionId: string, text: string) => {
      setExam((prev) => ({
        ...prev,
        sections: {
          ...prev.sections,
          [sectionId]: {
            ...prev.sections[sectionId],
            questions: prev.sections[sectionId].questions.map((q) =>
              q.id === questionId ? { ...q, text } : q
            ),
          },
        },
      }));
    },
    []
  );

  const handleQuestionScoreChange = useCallback(
    (sectionId: QuestionSectionType, questionId: string, score: number) => {
      setExam((prev) => ({
        ...prev,
        sections: {
          ...prev.sections,
          [sectionId]: updateQuestionScore(prev.sections[sectionId], questionId, score),
        },
      }));
    },
    []
  );

  const handleDeleteQuestion = useCallback(
    (sectionId: QuestionSectionType, questionId: string) => {
      setExam((prev) => ({
        ...prev,
        sections: {
          ...prev.sections,
          [sectionId]: deleteQuestionFromSection(prev.sections[sectionId], questionId),
        },
      }));
    },
    []
  );

  const handleAddBlankBlock = useCallback(() => {
    const id = createId('blank');
    setExam((prev) => ({
      ...prev,
      blankSections: [...prev.blankSections, { id }],
    }));
  }, []);

  const handleDeleteBlankBlock = useCallback((blankId: string) => {
    setExam((prev) => ({
      ...prev,
      blankSections: prev.blankSections.filter((b) => b.id !== blankId),
    }));
  }, []);

  const handleColumnsChange = useCallback((columnsPerRow: 2 | 3) => {
    setExam((prev) => ({ ...prev, columnsPerRow }));
  }, []);

  const handleResetExam = useCallback(() => {
    setExam(createDefaultExam());
    setExportError(null);
  }, []);

  const handlePrint = useCallback(() => {
    window.print();
  }, []);

  const handleDownloadStandalone = useCallback(async () => {
    setExportError(null);
    setIsDownloadingStandalone(true);
    try {
      let htmlContent = '';

      if (window.location.protocol === 'file:') {
        const clone = document.documentElement.cloneNode(true) as HTMLElement;
        const rootEl = clone.querySelector('#root');
        if (rootEl) rootEl.innerHTML = '';
        htmlContent = `<!doctype html>\n${clone.outerHTML}`;
      } else {
        const res = await fetch('./standalone.txt', { cache: 'no-store' });
        if (!res.ok) {
          throw new Error('找不到單檔建置版本，請重新建置專案。');
        }
        const text = await res.text();
        if (!text.includes('id="root"') && !text.includes("id='root'")) {
          throw new Error('單檔內容格式無效。');
        }
        htmlContent = text;
      }

      const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = '英文考卷製作工具_單檔版.html';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (err) {
      setExportError(
        err instanceof Error ? `單檔下載失敗：${err.message}` : '單檔下載失敗，請稍後再試。'
      );
    } finally {
      setIsDownloadingStandalone(false);
    }
  }, []);

  const handleExportWord = useCallback(async () => {
    setExportError(null);
    setIsExportingWord(true);
    try {
      await exportExamToDocx(exam);
    } catch (err) {
      setExportError(
        err instanceof Error ? `Word 匯出失敗：${err.message}` : 'Word 匯出失敗，請稍後再試。'
      );
    } finally {
      setIsExportingWord(false);
    }
  }, [exam]);

  const handleExportPdf = useCallback(async () => {
    setExportError(null);
    setIsExportingPdf(true);
    try {
      await exportExamToPdf(exam);
    } catch (err) {
      setExportError(
        err instanceof Error ? `PDF 匯出失敗：${err.message}` : 'PDF 匯出失敗，請稍後再試。'
      );
    } finally {
      setIsExportingPdf(false);
    }
  }, [exam]);

  return (
    <div className="min-h-screen bg-slate-100 print:bg-white">
      <TopToolbar
        pageCount={pageCount}
        zhCount={exam.sections.zhToEn.questions.length}
        enCount={exam.sections.enToZh.questions.length}
        columnsPerRow={exam.columnsPerRow}
        onColumnsChange={handleColumnsChange}
        onResetExam={handleResetExam}
        onPrint={handlePrint}
        onDownloadStandalone={handleDownloadStandalone}
        onExportWord={handleExportWord}
        onExportPdf={handleExportPdf}
        isDownloadingStandalone={isDownloadingStandalone}
        isExportingWord={isExportingWord}
        isExportingPdf={isExportingPdf}
      />

      {exportError && (
        <div className="print:hidden max-w-[794px] mx-auto mt-4 px-4 py-2.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-lg flex items-center justify-between">
          <span>{exportError}</span>
          <button
            type="button"
            onClick={() => setExportError(null)}
            className="text-rose-600 hover:text-rose-900 font-medium ml-4 cursor-pointer"
          >
            關閉
          </button>
        </div>
      )}

      <main>
        <ExamPaperWorkspace
          exam={exam}
          focusedQuestionId={focusedQuestionId}
          onFocusHandled={() => setFocusedQuestionId(null)}
          onHeaderChange={handleHeaderChange}
          onAddInfoField={handleAddInfoField}
          onSectionOrderChange={handleSectionOrderChange}
          onSectionTitleChange={handleSectionTitleChange}
          onSectionTargetTotalChange={handleSectionTargetTotalChange}
          onEnableAutoScore={handleEnableAutoScore}
          onAddQuestion={handleAddQuestion}
          onQuestionTextChange={handleQuestionTextChange}
          onQuestionScoreChange={handleQuestionScoreChange}
          onDeleteQuestion={handleDeleteQuestion}
          onAddBlankBlock={handleAddBlankBlock}
          onDeleteBlankBlock={handleDeleteBlankBlock}
          onPageCountChange={setPageCount}
        />
      </main>
    </div>
  );
}

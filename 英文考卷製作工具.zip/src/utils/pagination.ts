import { QuestionItem, QuestionSectionType } from '../types/exam';

export const QUESTIONS_PER_COLUMN = 5;

export interface NumberedQuestion {
  question: QuestionItem;
  number: number; // 1-based sequential question number
}

export interface QuestionBand {
  bandIndex: number;
  columns: NumberedQuestion[][]; // each inner array has up to 5 vertical items
}

/**
 * Arranges questions strictly 5 per vertical column, expanding rightward to new columns,
 * and groups columns into horizontal bands of `columnsPerRow` (2 or 3) so they fit cleanly on A4 portrait.
 */
export function buildQuestionBands(
  questions: QuestionItem[],
  columnsPerRow: 2 | 3
): QuestionBand[] {
  if (questions.length === 0) return [];

  const numbered: NumberedQuestion[] = questions.map((question, idx) => ({
    question,
    number: idx + 1,
  }));

  const allColumns: NumberedQuestion[][] = [];
  for (let i = 0; i < numbered.length; i += QUESTIONS_PER_COLUMN) {
    allColumns.push(numbered.slice(i, i + QUESTIONS_PER_COLUMN));
  }

  const bands: QuestionBand[] = [];
  for (let i = 0; i < allColumns.length; i += columnsPerRow) {
    bands.push({
      bandIndex: bands.length,
      columns: allColumns.slice(i, i + columnsPerRow),
    });
  }

  return bands;
}

export type ExamLayoutChunk =
  | {
      key: string;
      type: 'header';
    }
  | {
      key: string;
      type: 'section-empty';
      sectionId: QuestionSectionType;
      sectionOrderIndex: number;
    }
  | {
      key: string;
      type: 'section-band';
      sectionId: QuestionSectionType;
      sectionOrderIndex: number;
      band: QuestionBand;
      isFirstBand: boolean;
      isLastBand: boolean;
    }
  | {
      key: string;
      type: 'blank-block';
      blankId: string;
      blankIndex: number;
    };

/**
 * Packs measured layout chunks into A4 pages without ever splitting a band,
 * section header+first band, or blank block across page boundaries.
 */
export function packChunksIntoPages(
  chunks: ExamLayoutChunk[],
  heightsByKey: Record<string, number>,
  maxPageContentHeight: number
): ExamLayoutChunk[][] {
  if (chunks.length === 0) return [[]];

  const pages: ExamLayoutChunk[][] = [];
  let currentPage: ExamLayoutChunk[] = [];
  let currentHeight = 0;

  for (const chunk of chunks) {
    const chunkHeight = heightsByKey[chunk.key] ?? 120;
    const gapBefore = currentPage.length > 0 ? 12 : 0;

    if (
      currentPage.length > 0 &&
      currentHeight + gapBefore + chunkHeight > maxPageContentHeight
    ) {
      pages.push(currentPage);
      currentPage = [chunk];
      currentHeight = chunkHeight;
    } else {
      currentPage.push(chunk);
      currentHeight += gapBefore + chunkHeight;
    }
  }

  if (currentPage.length > 0) {
    pages.push(currentPage);
  }

  return pages;
}

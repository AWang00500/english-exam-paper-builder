import {
  AlignmentType,
  BorderStyle,
  convertMillimetersToTwip,
  Document,
  Footer,
  HeightRule,
  Packer,
  PageNumber,
  PageOrientation,
  Paragraph,
  Table,
  TableCell,
  TableLayoutType,
  TableRow,
  TextRun,
  UnderlineType,
  WidthType,
} from 'docx';
import { ExamDocument, QuestionSectionData, TextAlign } from '../types/exam';
import { buildQuestionBands } from './pagination';
import { formatScore, getChineseSectionNumeral, getSectionSumScore } from './scoring';

const NONE_BORDER = {
  style: BorderStyle.NONE,
  size: 0,
  color: 'FFFFFF',
};

const INVISIBLE_TABLE_BORDERS = {
  top: NONE_BORDER,
  bottom: NONE_BORDER,
  left: NONE_BORDER,
  right: NONE_BORDER,
  insideHorizontal: NONE_BORDER,
  insideVertical: NONE_BORDER,
};

const INVISIBLE_CELL_BORDERS = {
  top: NONE_BORDER,
  bottom: NONE_BORDER,
  left: NONE_BORDER,
  right: NONE_BORDER,
};

function mapAlignment(align: TextAlign): (typeof AlignmentType)[keyof typeof AlignmentType] {
  switch (align) {
    case 'left':
      return AlignmentType.LEFT;
    case 'right':
      return AlignmentType.RIGHT;
    default:
      return AlignmentType.CENTER;
  }
}

function buildSectionScoreSummary(section: QuestionSectionData): string {
  const count = section.questions.length;
  const total = getSectionSumScore(section);
  if (count === 0) {
    return '（共 0 題，總分 0 分）';
  }
  const firstScore = section.questions[0].score;
  const allEqual = section.questions.every((q) => Math.abs(q.score - firstScore) < 0.001);
  if (allEqual) {
    return `（共 ${count} 題，每題 ${formatScore(firstScore)} 分，總分 ${formatScore(total)} 分）`;
  }
  return `（共 ${count} 題，總分 ${formatScore(total)} 分）`;
}

function triggerDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function exportExamToDocx(exam: ExamDocument): Promise<void> {
  // A4 Portrait: 210mm x 297mm, margins 16mm => usable width = 178mm
  const usableWidthTwips = convertMillimetersToTwip(178);
  const children: (Paragraph | Table)[] = [];

  // 1. Header & Basic Info in user-defined order
  for (const subId of exam.header.order) {
    if (subId === 'title') {
      children.push(
        new Paragraph({
          alignment: mapAlignment(exam.header.titleAlign),
          spacing: { before: 0, after: 140 },
          children: [
            new TextRun({
              text: exam.header.title.trim() || '英文單字測驗',
              bold: true,
              size: 40, // 20pt
              color: '000000',
              font: {
                name: 'Plus Jakarta Sans',
                eastAsia: 'Microsoft JhengHei',
              },
            }),
          ],
        })
      );
    } else if (subId === 'info' && exam.header.infoFields.length > 0) {
      const fields = exam.header.infoFields;
      const cellWidth = Math.floor(usableWidthTwips / fields.length);

      children.push(
        new Table({
          width: { size: usableWidthTwips, type: WidthType.DXA },
          layout: TableLayoutType.FIXED,
          borders: INVISIBLE_TABLE_BORDERS,
          rows: [
            new TableRow({
              cantSplit: true,
              children: fields.map(
                (field) =>
                  new TableCell({
                    width: { size: cellWidth, type: WidthType.DXA },
                    borders: INVISIBLE_CELL_BORDERS,
                    margins: { top: 40, bottom: 120, left: 40, right: 40 },
                    children: [
                      new Paragraph({
                        alignment: mapAlignment(exam.header.infoAlign),
                        children: [
                          new TextRun({
                            text: field.text,
                            size: 21, // 10.5pt
                            color: '000000',
                            font: {
                              name: 'Plus Jakarta Sans',
                              eastAsia: 'Microsoft JhengHei',
                            },
                          }),
                        ],
                      }),
                    ],
                  })
              ),
            }),
          ],
        })
      );
    }
  }

  // Subtle divider line beneath header
  children.push(
    new Paragraph({
      spacing: { before: 40, after: 200 },
      border: {
        bottom: {
          color: '111827',
          space: 4,
          style: BorderStyle.SINGLE,
          size: 8,
        },
      },
      children: [],
    })
  );

  // 2. Formal Question Sections in user-defined dragged order
  exam.sectionOrder.forEach((sectionId, sectionIdx) => {
    const section = exam.sections[sectionId];
    const numeral = getChineseSectionNumeral(sectionIdx);
    const titleText = `${numeral}、${section.title.trim() || (sectionId === 'zhToEn' ? '中翻英' : '英翻中')}`;
    const summaryText = buildSectionScoreSummary(section);

    children.push(
      new Paragraph({
        keepNext: true,
        spacing: { before: sectionIdx === 0 ? 40 : 240, after: 120 },
        children: [
          new TextRun({
            text: titleText,
            bold: true,
            size: 26, // 13pt
            color: '000000',
            font: {
              name: 'Plus Jakarta Sans',
              eastAsia: 'Microsoft JhengHei',
            },
          }),
          new TextRun({
            text: `  ${summaryText}`,
            size: 20, // 10pt
            color: '374151',
            font: {
              name: 'Plus Jakarta Sans',
              eastAsia: 'Microsoft JhengHei',
            },
          }),
        ],
      })
    );

    if (section.questions.length === 0) {
      children.push(
        new Paragraph({
          spacing: { before: 40, after: 160 },
          children: [
            new TextRun({
              text: '（本大題尚無題目）',
              italics: true,
              size: 21,
              color: '6B7280',
              font: {
                name: 'Plus Jakarta Sans',
                eastAsia: 'Microsoft JhengHei',
              },
            }),
          ],
        })
      );
      return;
    }

    const bands = buildQuestionBands(section.questions, exam.columnsPerRow);
    const colCount = exam.columnsPerRow;
    const colWidth = Math.floor(usableWidthTwips / colCount);

    bands.forEach((band, bandIdx) => {
      // Determine how many rows this band actually needs (max 5, no forced empty padding if < 5)
      const maxRowsInBand = Math.max(...band.columns.map((col) => col.length), 1);
      const rows: TableRow[] = [];

      for (let r = 0; r < maxRowsInBand; r++) {
        const cells: TableCell[] = [];
        for (let c = 0; c < colCount; c++) {
          const item = band.columns[c]?.[r];
          if (!item) {
            cells.push(
              new TableCell({
                width: { size: colWidth, type: WidthType.DXA },
                borders: INVISIBLE_CELL_BORDERS,
                margins: { top: 60, bottom: 80, left: 40, right: 100 },
                children: [new Paragraph({ children: [] })],
              })
            );
          } else {
            const promptLabel = item.question.text.trim() || '________';
            cells.push(
              new TableCell({
                width: { size: colWidth, type: WidthType.DXA },
                borders: INVISIBLE_CELL_BORDERS,
                margins: { top: 60, bottom: 90, left: 40, right: 100 },
                children: [
                  new Paragraph({
                    spacing: { before: 0, after: 0, line: 300 },
                    children: [
                      new TextRun({
                        text: `${item.number}. `,
                        bold: true,
                        size: 22, // 11pt
                        color: '000000',
                        font: {
                          name: 'Plus Jakarta Sans',
                          eastAsia: 'Microsoft JhengHei',
                        },
                      }),
                      new TextRun({
                        text: `${promptLabel}：`,
                        size: 22,
                        color: '000000',
                        font: {
                          name: 'Plus Jakarta Sans',
                          eastAsia: 'Microsoft JhengHei',
                        },
                      }),
                      // Uniform fixed-length handwritten answer blank (~30mm = 14 monospace NBSPs)
                      new TextRun({
                        text: '\u00A0'.repeat(14),
                        underline: {
                          type: UnderlineType.SINGLE,
                          color: '000000',
                        },
                        size: 22,
                        font: {
                          name: 'Courier New',
                          eastAsia: 'Courier New',
                        },
                      }),
                      new TextRun({
                        text: ` (${formatScore(item.question.score)}分)`,
                        size: 18, // 9pt
                        color: '374151',
                        font: {
                          name: 'Plus Jakarta Sans',
                          eastAsia: 'Microsoft JhengHei',
                        },
                      }),
                    ],
                  }),
                ],
              })
            );
          }
        }

        rows.push(
          new TableRow({
            cantSplit: true,
            children: cells,
          })
        );
      }

      children.push(
        new Table({
          width: { size: usableWidthTwips, type: WidthType.DXA },
          layout: TableLayoutType.FIXED,
          borders: INVISIBLE_TABLE_BORDERS,
          rows,
        })
      );

      if (bandIdx < bands.length - 1) {
        children.push(
          new Paragraph({
            spacing: { before: 40, after: 80 },
            children: [],
          })
        );
      }
    });
  });

  // 3. Blank Blocks (always positioned below all formal question sections)
  if (exam.blankSections.length > 0) {
    exam.blankSections.forEach(() => {
      children.push(
        new Paragraph({
          spacing: { before: 140, after: 0 },
          children: [],
        })
      );
      children.push(
        new Table({
          width: { size: usableWidthTwips, type: WidthType.DXA },
          layout: TableLayoutType.FIXED,
          borders: INVISIBLE_TABLE_BORDERS,
          rows: [
            new TableRow({
              cantSplit: true,
              height: {
                value: convertMillimetersToTwip(42),
                rule: HeightRule.ATLEAST,
              },
              children: [
                new TableCell({
                  width: { size: usableWidthTwips, type: WidthType.DXA },
                  borders: INVISIBLE_CELL_BORDERS,
                  children: [new Paragraph({ children: [] })],
                }),
              ],
            }),
          ],
        })
      );
    });
  }

  const doc = new Document({
    creator: '英文考卷製作工具',
    title: exam.header.title.trim() || '英文單字測驗',
    sections: [
      {
        properties: {
          page: {
            size: {
              width: convertMillimetersToTwip(210),
              height: convertMillimetersToTwip(297),
              orientation: PageOrientation.PORTRAIT,
            },
            margin: {
              top: convertMillimetersToTwip(16),
              bottom: convertMillimetersToTwip(16),
              left: convertMillimetersToTwip(16),
              right: convertMillimetersToTwip(16),
            },
          },
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({
                    text: '第 ',
                    size: 18,
                    color: '6B7280',
                    font: { name: 'Plus Jakarta Sans', eastAsia: 'Microsoft JhengHei' },
                  }),
                  new TextRun({
                    children: [PageNumber.CURRENT],
                    size: 18,
                    color: '6B7280',
                  }),
                  new TextRun({
                    text: ' 頁 / 共 ',
                    size: 18,
                    color: '6B7280',
                    font: { name: 'Plus Jakarta Sans', eastAsia: 'Microsoft JhengHei' },
                  }),
                  new TextRun({
                    children: [PageNumber.TOTAL_PAGES],
                    size: 18,
                    color: '6B7280',
                  }),
                  new TextRun({
                    text: ' 頁',
                    size: 18,
                    color: '6B7280',
                    font: { name: 'Plus Jakarta Sans', eastAsia: 'Microsoft JhengHei' },
                  }),
                ],
              }),
            ],
          }),
        },
        children,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const safeName = (exam.header.title.trim() || '英文單字測驗').replace(/[\\/:*?"<>|]/g, '_');
  triggerDownload(blob, `${safeName}.docx`);
}

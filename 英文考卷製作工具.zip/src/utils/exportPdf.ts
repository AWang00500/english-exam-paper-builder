import { jsPDF } from 'jspdf';
import { ExamDocument, QuestionSectionData, TextAlign } from '../types/exam';
import { buildQuestionBands, QuestionBand } from './pagination';
import { formatScore, getChineseSectionNumeral, getSectionSumScore } from './scoring';

const FONT_REGULAR_URLS = [
  'https://fonts.gstatic.com/s/notosanstc/v40/-nFuOG829Oofr2wohFbTp9ifNAn722rq0MXz76Cy_Co.ttf',
  'https://cdn.jsdelivr.net/gh/justfont/open-huninn-font@master/font/jf-openhuninn-2.0.ttf',
];

const FONT_BOLD_URLS = [
  'https://fonts.gstatic.com/s/notosanstc/v40/-nFuOG829Oofr2wohFbTp9ifNAn722rq0MXz70e1_Co.ttf',
];

interface CachedFontPair {
  regularBase64: string;
  boldBase64: string | null;
}

let cachedFonts: CachedFontPair | null = null;
let fontLoadPromise: Promise<CachedFontPair> | null = null;

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const slice = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode(...slice);
  }
  return btoa(binary);
}

async function fetchFirstAvailableFont(urls: string[]): Promise<string | null> {
  for (const url of urls) {
    try {
      const response = await fetch(url, { mode: 'cors' });
      if (!response.ok) continue;
      const buf = await response.arrayBuffer();
      if (buf.byteLength > 100_000) {
        return arrayBufferToBase64(buf);
      }
    } catch {
      // Try next fallback URL
    }
  }
  return null;
}

async function loadTraditionalChineseFonts(): Promise<CachedFontPair> {
  if (cachedFonts) return cachedFonts;
  if (fontLoadPromise) return fontLoadPromise;

  fontLoadPromise = (async () => {
    const [regularBase64, boldBase64] = await Promise.all([
      fetchFirstAvailableFont(FONT_REGULAR_URLS),
      fetchFirstAvailableFont(FONT_BOLD_URLS),
    ]);

    if (!regularBase64) {
      fontLoadPromise = null;
      throw new Error('無法載入繁體中文字型，請確認網路連線後重試。');
    }

    cachedFonts = { regularBase64, boldBase64 };
    return cachedFonts;
  })();

  return fontLoadPromise;
}

function buildSectionScoreSummary(section: QuestionSectionData): string {
  const count = section.questions.length;
  const total = getSectionSumScore(section);
  if (count === 0) return '（共 0 題，總分 0 分）';
  const firstScore = section.questions[0].score;
  const allEqual = section.questions.every((q) => Math.abs(q.score - firstScore) < 0.001);
  if (allEqual) {
    return `（共 ${count} 題，每題 ${formatScore(firstScore)} 分，總分 ${formatScore(total)} 分）`;
  }
  return `（共 ${count} 題，總分 ${formatScore(total)} 分）`;
}

function getAlignedX(align: TextAlign, margin: number, usableWidth: number): { x: number; align: 'left' | 'center' | 'right' } {
  if (align === 'left') return { x: margin, align: 'left' };
  if (align === 'right') return { x: margin + usableWidth, align: 'right' };
  return { x: margin + usableWidth / 2, align: 'center' };
}

export async function exportExamToPdf(exam: ExamDocument): Promise<void> {
  const fonts = await loadTraditionalChineseFonts();

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  doc.addFileToVFS('NotoSansTC-Regular.ttf', fonts.regularBase64);
  doc.addFont('NotoSansTC-Regular.ttf', 'NotoSansTC', 'normal');
  if (fonts.boldBase64) {
    doc.addFileToVFS('NotoSansTC-Bold.ttf', fonts.boldBase64);
    doc.addFont('NotoSansTC-Bold.ttf', 'NotoSansTC', 'bold');
  } else {
    doc.addFont('NotoSansTC-Regular.ttf', 'NotoSansTC', 'bold');
  }

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 16;
  const usableWidth = pageWidth - margin * 2; // 178mm
  const maxContentY = pageHeight - 20; // leave bottom margin for footer
  const blankLineWidthMm = 30; // uniform fixed answer blank (~10+ English letters)

  let y = margin;

  const ensureSpace = (neededMm: number) => {
    if (y + neededMm > maxContentY) {
      doc.addPage('a4', 'portrait');
      y = margin;
    }
  };

  // 1. Header & Basic Info (in exact user-defined order)
  for (const subId of exam.header.order) {
    if (subId === 'title') {
      const titleText = exam.header.title.trim() || '英文單字測驗';
      doc.setFont('NotoSansTC', 'bold');
      doc.setFontSize(19);
      doc.setTextColor(17, 24, 39);
      const pos = getAlignedX(exam.header.titleAlign, margin, usableWidth);
      const wrappedTitle = doc.splitTextToSize(titleText, usableWidth) as string[];
      wrappedTitle.forEach((line) => {
        doc.text(line, pos.x, y + 6, { align: pos.align });
        y += 8.5;
      });
      y += 2;
    } else if (subId === 'info' && exam.header.infoFields.length > 0) {
      doc.setFont('NotoSansTC', 'normal');
      doc.setFontSize(10.5);
      doc.setTextColor(31, 41, 55);

      const fields = exam.header.infoFields;
      const colW = usableWidth / fields.length;

      fields.forEach((field, idx) => {
        const cellStart = margin + idx * colW;
        let textX = cellStart + colW / 2;
        let align: 'left' | 'center' | 'right' = 'center';
        if (exam.header.infoAlign === 'left') {
          textX = cellStart;
          align = 'left';
        } else if (exam.header.infoAlign === 'right') {
          textX = cellStart + colW;
          align = 'right';
        }
        doc.text(field.text, textX, y + 4.5, { align, maxWidth: colW - 2 });
      });
      y += 8;
    }
  }

  // Header bottom rule
  doc.setDrawColor(17, 24, 39);
  doc.setLineWidth(0.45);
  doc.line(margin, y + 1.5, margin + usableWidth, y + 1.5);
  y += 8;

  // Helper to compute exact height of a 5-per-column band before drawing
  const measureBandHeight = (band: QuestionBand, colWidth: number): { bandHeight: number; rowHeights: number[] } => {
    const maxRows = Math.max(...band.columns.map((c) => c.length), 1);
    const rowHeights: number[] = [];

    doc.setFont('NotoSansTC', 'normal');
    doc.setFontSize(10.5);

    for (let r = 0; r < maxRows; r++) {
      let maxRowH = 7.8;
      for (let c = 0; c < exam.columnsPerRow; c++) {
        const item = band.columns[c]?.[r];
        if (!item) continue;
        const promptText = `${item.number}. ${item.question.text.trim() || '________'}：`;
        const scoreText = `(${formatScore(item.question.score)}分)`;
        const scoreWidth = doc.getTextWidth(scoreText);
        const promptWidth = doc.getTextWidth(promptText);
        const availableInline = colWidth - 4 - blankLineWidthMm - scoreWidth - 2;
        if (promptWidth > availableInline) {
          // Prompt wraps above blank or onto 2 lines
          const lines = doc.splitTextToSize(promptText, colWidth - 5) as string[];
          const needed = lines.length * 4.8 + 6.5;
          if (needed > maxRowH) maxRowH = needed;
        }
      }
      rowHeights.push(maxRowH);
    }

    const bandHeight = rowHeights.reduce((a, b) => a + b, 0) + 3;
    return { bandHeight, rowHeights };
  };

  // 2. Formal Question Sections in user-defined order
  exam.sectionOrder.forEach((sectionId, sectionIdx) => {
    const section = exam.sections[sectionId];
    const numeral = getChineseSectionNumeral(sectionIdx);
    const titleText = `${numeral}、${section.title.trim() || (sectionId === 'zhToEn' ? '中翻英' : '英翻中')}`;
    const summaryText = buildSectionScoreSummary(section);

    const colGap = 6;
    const colCount = exam.columnsPerRow;
    const colWidth = (usableWidth - colGap * (colCount - 1)) / colCount;
    const bands = buildQuestionBands(section.questions, colCount);

    // Measure section header + first band together so header is never orphaned
    const firstBandMetrics = bands.length > 0 ? measureBandHeight(bands[0], colWidth) : null;
    const headerHeight = 9;
    const initialNeeded = headerHeight + (firstBandMetrics ? firstBandMetrics.bandHeight : 10);

    if (sectionIdx > 0) {
      y += 4;
    }
    ensureSpace(initialNeeded);

    // Draw Section Header
    doc.setFont('NotoSansTC', 'bold');
    doc.setFontSize(12.5);
    doc.setTextColor(17, 24, 39);
    doc.text(titleText, margin, y + 4.5);
    const titleWidth = doc.getTextWidth(titleText);

    doc.setFont('NotoSansTC', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(75, 85, 99);
    doc.text(summaryText, margin + titleWidth + 2.5, y + 4.5);

    y += headerHeight;

    if (bands.length === 0) {
      doc.setFont('NotoSansTC', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(107, 114, 128);
      doc.text('（本大題尚無題目）', margin + 2, y + 4);
      y += 10;
      return;
    }

    bands.forEach((band) => {
      const { bandHeight, rowHeights } = measureBandHeight(band, colWidth);
      ensureSpace(bandHeight);

      let rowY = y;
      const maxRows = rowHeights.length;

      for (let r = 0; r < maxRows; r++) {
        const rowH = rowHeights[r];

        for (let c = 0; c < colCount; c++) {
          const item = band.columns[c]?.[r];
          if (!item) continue;

          const cellX = margin + c * (colWidth + colGap);
          const numStr = `${item.number}. `;
          const promptStr = `${item.question.text.trim() || '________'}：`;
          const scoreStr = `(${formatScore(item.question.score)}分)`;

          doc.setFont('NotoSansTC', 'bold');
          doc.setFontSize(10.5);
          const numWidth = doc.getTextWidth(numStr);

          doc.setFont('NotoSansTC', 'normal');
          doc.setFontSize(10.5);
          const promptWidth = doc.getTextWidth(promptStr);

          doc.setFontSize(8.5);
          const scoreWidth = doc.getTextWidth(scoreStr);

          const fullLineWidth = numWidth + promptWidth + blankLineWidthMm + 1.5 + scoreWidth;

          if (fullLineWidth <= colWidth) {
            // Single crisp horizontal line
            const baselineY = rowY + 5;
            doc.setFont('NotoSansTC', 'bold');
            doc.setFontSize(10.5);
            doc.setTextColor(17, 24, 39);
            doc.text(numStr, cellX, baselineY);

            doc.setFont('NotoSansTC', 'normal');
            doc.text(promptStr, cellX + numWidth, baselineY);

            const lineStartX = cellX + numWidth + promptWidth + 0.5;
            doc.setDrawColor(17, 24, 39);
            doc.setLineWidth(0.3);
            doc.line(lineStartX, baselineY + 0.6, lineStartX + blankLineWidthMm, baselineY + 0.6);

            doc.setFontSize(8.5);
            doc.setTextColor(75, 85, 99);
            doc.text(scoreStr, lineStartX + blankLineWidthMm + 1.5, baselineY);
          } else {
            // Wrap long prompt text cleanly above the fixed-length answer line
            doc.setFont('NotoSansTC', 'normal');
            doc.setFontSize(10.5);
            doc.setTextColor(17, 24, 39);
            const fullPrompt = `${numStr}${promptStr}`;
            const lines = doc.splitTextToSize(fullPrompt, colWidth - 2) as string[];
            let textY = rowY + 4.5;
            lines.forEach((line) => {
              doc.text(line, cellX, textY);
              textY += 4.6;
            });

            const blankY = textY + 1;
            doc.setDrawColor(17, 24, 39);
            doc.setLineWidth(0.3);
            doc.line(cellX + 4, blankY + 0.5, cellX + 4 + blankLineWidthMm, blankY + 0.5);

            doc.setFontSize(8.5);
            doc.setTextColor(75, 85, 99);
            doc.text(scoreStr, cellX + 4 + blankLineWidthMm + 1.5, blankY);
          }
        }

        rowY += rowH;
      }

      y += bandHeight;
    });
  });

  // 3. Blank Blocks (always positioned below all formal question sections)
  const blankBlockHeightMm = 42;
  exam.blankSections.forEach(() => {
    y += 4;
    ensureSpace(blankBlockHeightMm);
    y += blankBlockHeightMm;
  });

  // 4. Page Numbers Footer on all pages
  const totalPages = doc.getNumberOfPages();
  doc.setFont('NotoSansTC', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(107, 114, 128);
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    doc.text(`第 ${p} 頁 / 共 ${totalPages} 頁`, pageWidth / 2, pageHeight - 9, {
      align: 'center',
    });
  }

  const safeName = (exam.header.title.trim() || '英文單字測驗').replace(/[\\/:*?"<>|]/g, '_');
  doc.save(`${safeName}.pdf`);
}

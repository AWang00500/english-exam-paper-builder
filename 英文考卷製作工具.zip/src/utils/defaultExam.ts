import { ExamDocument } from '../types/exam';
import { recalculateAutoScores } from './scoring';

export function createId(prefix = 'id'): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return `${prefix}_${crypto.randomUUID().slice(0, 8)}`;
  }
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

export function createDefaultExam(): ExamDocument {
  const zhQuestions = ['蘋果', '香蕉', '學校', '書本', '桌子'].map((text, idx) => ({
    id: `zh_init_${idx + 1}`,
    text,
    score: 20,
  }));

  const enQuestions = ['Apple', 'Banana', 'School', 'Book', 'Table'].map((text, idx) => ({
    id: `en_init_${idx + 1}`,
    text,
    score: 20,
  }));

  return {
    header: {
      title: '英文單字測驗',
      titleAlign: 'center',
      infoAlign: 'center',
      order: ['title', 'info'],
      infoFields: [
        { id: 'info_class', text: '班級：__________' },
        { id: 'info_name', text: '姓名：__________' },
        { id: 'info_seat', text: '座號：______' },
        { id: 'info_date', text: '日期：__________' },
      ],
    },
    sectionOrder: ['zhToEn', 'enToZh'],
    sections: {
      zhToEn: {
        id: 'zhToEn',
        title: '中翻英',
        isAutoScore: true,
        targetTotalScore: 100,
        questions: recalculateAutoScores(zhQuestions, 100),
      },
      enToZh: {
        id: 'enToZh',
        title: '英翻中',
        isAutoScore: true,
        targetTotalScore: 100,
        questions: recalculateAutoScores(enQuestions, 100),
      },
    },
    blankSections: [],
    columnsPerRow: 2,
  };
}

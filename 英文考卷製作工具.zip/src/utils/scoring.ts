import { QuestionItem, QuestionSectionData } from '../types/exam';

/**
 * Evenly distributes `targetTotalScore` across all questions in a section.
 * Rounds to at most 2 decimal places for clean display.
 */
export function recalculateAutoScores(
  questions: QuestionItem[],
  targetTotalScore: number
): QuestionItem[] {
  if (questions.length === 0) return [];
  const safeTotal = Number.isFinite(targetTotalScore) && targetTotalScore >= 0 ? targetTotalScore : 0;
  const perQuestion = Number((safeTotal / questions.length).toFixed(2));
  return questions.map((q) => ({
    ...q,
    score: perQuestion,
  }));
}

/**
 * Adds a new question to the section.
 * - If isAutoScore is true: recalculates every question's score evenly.
 * - If isAutoScore is false: preserves ALL existing questions' scores untouched.
 */
export function addQuestionToSection(
  section: QuestionSectionData,
  newId: string,
  text = ''
): QuestionSectionData {
  const fallbackScore =
    section.questions.length > 0
      ? section.questions[section.questions.length - 1].score
      : 5;

  const nextQuestions: QuestionItem[] = [
    ...section.questions,
    {
      id: newId,
      text,
      score: section.isAutoScore ? 0 : fallbackScore,
    },
  ];

  return {
    ...section,
    questions: section.isAutoScore
      ? recalculateAutoScores(nextQuestions, section.targetTotalScore)
      : nextQuestions,
  };
}

/**
 * Deletes a question from the section.
 * - If isAutoScore is true: recalculates remaining questions' scores evenly.
 * - If isAutoScore is false: preserves ALL remaining questions' scores untouched.
 */
export function deleteQuestionFromSection(
  section: QuestionSectionData,
  questionId: string
): QuestionSectionData {
  const nextQuestions = section.questions.filter((q) => q.id !== questionId);
  return {
    ...section,
    questions: section.isAutoScore
      ? recalculateAutoScores(nextQuestions, section.targetTotalScore)
      : nextQuestions,
  };
}

/**
 * Manually modifies one question's score.
 * Immediately disables auto-average scoring (`isAutoScore = false`) for THIS section only,
 * leaving all other questions' scores completely untouched.
 */
export function updateQuestionScore(
  section: QuestionSectionData,
  questionId: string,
  rawScore: number
): QuestionSectionData {
  const cleanScore = Number.isFinite(rawScore) && rawScore >= 0 ? Number(rawScore.toFixed(2)) : 0;
  return {
    ...section,
    isAutoScore: false,
    questions: section.questions.map((q) =>
      q.id === questionId ? { ...q, score: cleanScore } : q
    ),
  };
}

/**
 * Updates the section target total score (used in auto mode).
 * When in auto mode, immediately recalculates every question's score.
 */
export function updateSectionTargetTotal(
  section: QuestionSectionData,
  rawTotal: number
): QuestionSectionData {
  const cleanTotal = Number.isFinite(rawTotal) && rawTotal >= 0 ? Number(rawTotal.toFixed(2)) : 0;
  return {
    ...section,
    targetTotalScore: cleanTotal,
    questions: section.isAutoScore
      ? recalculateAutoScores(section.questions, cleanTotal)
      : section.questions,
  };
}

/**
 * Re-enables auto-average scoring for the section and recalculates scores evenly.
 */
export function enableAutoScore(section: QuestionSectionData): QuestionSectionData {
  return {
    ...section,
    isAutoScore: true,
    questions: recalculateAutoScores(section.questions, section.targetTotalScore),
  };
}

/**
 * Returns the actual displayed sum of scores in the section.
 */
export function getSectionSumScore(section: QuestionSectionData): number {
  if (section.questions.length === 0) return 0;
  const sum = section.questions.reduce((acc, q) => acc + (Number.isFinite(q.score) ? q.score : 0), 0);
  return Number(sum.toFixed(2));
}

export function formatScore(score: number): string {
  if (!Number.isFinite(score)) return '0';
  return Number(score.toFixed(2)).toString();
}

export function getChineseSectionNumeral(index: number): string {
  const numerals = ['一', '二', '三', '四', '五', '六'];
  return numerals[index] ?? String(index + 1);
}

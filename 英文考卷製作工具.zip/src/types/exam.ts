export type HeaderSubBlockId = 'title' | 'info';

export type TextAlign = 'left' | 'center' | 'right';

export interface BasicInfoField {
  id: string;
  text: string;
}

export interface ExamHeaderData {
  title: string;
  titleAlign: TextAlign;
  infoAlign: TextAlign;
  order: HeaderSubBlockId[];
  infoFields: BasicInfoField[];
}

export interface QuestionItem {
  id: string;
  text: string;
  score: number;
}

export type QuestionSectionType = 'zhToEn' | 'enToZh';

export interface QuestionSectionData {
  id: QuestionSectionType;
  title: string;
  isAutoScore: boolean;
  targetTotalScore: number;
  questions: QuestionItem[];
}

export interface BlankSectionData {
  id: string;
}

export interface ExamDocument {
  header: ExamHeaderData;
  sectionOrder: QuestionSectionType[];
  sections: Record<QuestionSectionType, QuestionSectionData>;
  blankSections: BlankSectionData[];
  columnsPerRow: 2 | 3;
}

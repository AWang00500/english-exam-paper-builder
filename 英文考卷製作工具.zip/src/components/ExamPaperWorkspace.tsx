import {
  closestCenter,
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Plus } from 'lucide-react';
import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import {
  ExamDocument,
  ExamHeaderData,
  QuestionSectionData,
  QuestionSectionType,
} from '../types/exam';
import {
  buildQuestionBands,
  ExamLayoutChunk,
  packChunksIntoPages,
} from '../utils/pagination';
import { getChineseSectionNumeral } from '../utils/scoring';
import { BlankBlockView } from './BlankBlockView';
import { ExamHeaderBlock } from './ExamHeaderBlock';
import { QuestionBandView } from './QuestionBandView';
import { SectionHeaderBar } from './SectionHeaderBar';

interface ExamPaperWorkspaceProps {
  exam: ExamDocument;
  focusedQuestionId: string | null;
  onFocusHandled: () => void;
  onHeaderChange: (header: ExamHeaderData) => void;
  onAddInfoField: () => void;
  onSectionOrderChange: (order: QuestionSectionType[]) => void;
  onSectionTitleChange: (sectionId: QuestionSectionType, title: string) => void;
  onSectionTargetTotalChange: (sectionId: QuestionSectionType, total: number) => void;
  onEnableAutoScore: (sectionId: QuestionSectionType) => void;
  onAddQuestion: (sectionId: QuestionSectionType) => void;
  onQuestionTextChange: (
    sectionId: QuestionSectionType,
    questionId: string,
    text: string
  ) => void;
  onQuestionScoreChange: (
    sectionId: QuestionSectionType,
    questionId: string,
    score: number
  ) => void;
  onDeleteQuestion: (sectionId: QuestionSectionType, questionId: string) => void;
  onAddBlankBlock: () => void;
  onDeleteBlankBlock: (blankId: string) => void;
  onPageCountChange: (count: number) => void;
}

const MAX_PAGE_CONTENT_HEIGHT_PX = 956;

interface SortableSectionStarterProps {
  sectionId: QuestionSectionType;
  isActiveDropTarget: boolean;
  children: (props: {
    dragHandleProps: Record<string, unknown>;
    setActivatorRef: (el: HTMLElement | null) => void;
    isDragging: boolean;
  }) => React.ReactNode;
}

const SortableSectionStarter: React.FC<SortableSectionStarterProps> = ({
  sectionId,
  isActiveDropTarget,
  children,
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    setActivatorNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: sectionId });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`rounded-lg transition-all ${
        isDragging
          ? 'opacity-40 ring-2 ring-blue-500 bg-blue-50/40'
          : isActiveDropTarget
            ? 'ring-2 ring-dashed ring-blue-500 bg-blue-50/30 p-2 -m-2'
            : ''
      }`}
    >
      {children({
        dragHandleProps: { ...attributes, ...listeners },
        setActivatorRef: setActivatorNodeRef,
        isDragging,
      })}
    </div>
  );
};

export const ExamPaperWorkspace: React.FC<ExamPaperWorkspaceProps> = ({
  exam,
  focusedQuestionId,
  onFocusHandled,
  onHeaderChange,
  onAddInfoField,
  onSectionOrderChange,
  onSectionTitleChange,
  onSectionTargetTotalChange,
  onEnableAutoScore,
  onAddQuestion,
  onQuestionTextChange,
  onQuestionScoreChange,
  onDeleteQuestion,
  onAddBlankBlock,
  onDeleteBlankBlock,
  onPageCountChange,
}) => {
  const [activeDragSection, setActiveDragSection] = useState<QuestionSectionType | null>(null);
  const [heightsByKey, setHeightsByKey] = useState<Record<string, number>>({});
  const measureRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  // Build sequential atomic layout chunks
  const chunks = useMemo<ExamLayoutChunk[]>(() => {
    const list: ExamLayoutChunk[] = [{ key: 'header', type: 'header' }];

    exam.sectionOrder.forEach((sectionId, sectionOrderIndex) => {
      const section = exam.sections[sectionId];
      const bands = buildQuestionBands(section.questions, exam.columnsPerRow);

      if (bands.length === 0) {
        list.push({
          key: `section_${sectionId}_empty`,
          type: 'section-empty',
          sectionId,
          sectionOrderIndex,
        });
      } else {
        bands.forEach((band, idx) => {
          list.push({
            key: `section_${sectionId}_band_${idx}`,
            type: 'section-band',
            sectionId,
            sectionOrderIndex,
            band,
            isFirstBand: idx === 0,
            isLastBand: idx === bands.length - 1,
          });
        });
      }
    });

    exam.blankSections.forEach((blank, blankIndex) => {
      list.push({
        key: `blank_${blank.id}`,
        type: 'blank-block',
        blankId: blank.id,
        blankIndex,
      });
    });

    return list;
  }, [exam]);

  const measureChunks = useCallback(() => {
    const nextHeights: Record<string, number> = {};
    let changed = false;

    for (const chunk of chunks) {
      const el = measureRefs.current[chunk.key];
      const h = el ? Math.ceil(el.getBoundingClientRect().height) : 120;
      nextHeights[chunk.key] = h;
      if (heightsByKey[chunk.key] !== h) {
        changed = true;
      }
    }

    if (changed || Object.keys(heightsByKey).length !== chunks.length) {
      setHeightsByKey(nextHeights);
    }
  }, [chunks, heightsByKey]);

  useLayoutEffect(() => {
    measureChunks();
  }, [measureChunks]);

  const pages = useMemo(
    () => packChunksIntoPages(chunks, heightsByKey, MAX_PAGE_CONTENT_HEIGHT_PX),
    [chunks, heightsByKey]
  );

  useEffect(() => {
    onPageCountChange(pages.length);
  }, [pages.length, onPageCountChange]);

  const handleDragStart = (event: DragStartEvent) => {
    setActiveDragSection(event.active.id as QuestionSectionType);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveDragSection(null);
    if (!over || active.id === over.id) return;

    const oldIndex = exam.sectionOrder.indexOf(active.id as QuestionSectionType);
    const newIndex = exam.sectionOrder.indexOf(over.id as QuestionSectionType);
    if (oldIndex === -1 || newIndex === -1) return;

    onSectionOrderChange(arrayMove(exam.sectionOrder, oldIndex, newIndex));
  };

  const handleSwapSections = () => {
    onSectionOrderChange([...exam.sectionOrder].reverse());
  };

  const renderSectionAddButton = (sectionId: QuestionSectionType) => (
    <div className="print:hidden pt-2 pb-1">
      <button
        type="button"
        onClick={() => onAddQuestion(sectionId)}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50/80 hover:bg-blue-100 border border-blue-200/80 rounded-md transition-colors cursor-pointer"
      >
        <Plus className="w-3.5 h-3.5" />
        新增一題
      </button>
    </div>
  );

  const renderChunk = (chunk: ExamLayoutChunk, readOnlyPreview = false) => {
    if (chunk.type === 'header') {
      return (
        <ExamHeaderBlock
          header={exam.header}
          onChange={onHeaderChange}
          onAddInfoField={onAddInfoField}
          readOnlyPreview={readOnlyPreview}
        />
      );
    }

    if (chunk.type === 'section-empty') {
      const section: QuestionSectionData = exam.sections[chunk.sectionId];
      if (readOnlyPreview) {
        return (
          <div className="pt-2 pb-3">
            <SectionHeaderBar
              section={section}
              sectionOrderIndex={chunk.sectionOrderIndex}
              onTitleChange={() => {}}
              onTargetTotalChange={() => {}}
              onEnableAutoScore={() => {}}
              onSwapSections={() => {}}
              readOnlyPreview
            />
            <div className="text-sm text-slate-400 py-2">（本大題尚無題目）</div>
            <div className="h-[34px]" />
          </div>
        );
      }

      return (
        <SortableSectionStarter
          sectionId={chunk.sectionId}
          isActiveDropTarget={
            activeDragSection !== null && activeDragSection !== chunk.sectionId
          }
        >
          {({ dragHandleProps, setActivatorRef }) => (
            <div className="pt-2 pb-3">
              <SectionHeaderBar
                section={section}
                sectionOrderIndex={chunk.sectionOrderIndex}
                onTitleChange={(t) => onSectionTitleChange(chunk.sectionId, t)}
                onTargetTotalChange={(v) => onSectionTargetTotalChange(chunk.sectionId, v)}
                onEnableAutoScore={() => onEnableAutoScore(chunk.sectionId)}
                onSwapSections={handleSwapSections}
                dragHandleProps={dragHandleProps}
                setDragActivatorRef={setActivatorRef}
              />
              <div className="text-sm text-slate-400 py-2">
                尚無題目，請點擊下方「＋新增一題」建立翻譯題目。
              </div>
              {renderSectionAddButton(chunk.sectionId)}
            </div>
          )}
        </SortableSectionStarter>
      );
    }

    if (chunk.type === 'section-band') {
      const section = exam.sections[chunk.sectionId];
      const placeholder = chunk.sectionId === 'zhToEn' ? '輸入中文題目' : '輸入英文單字';

      const bandContent = (
        <div className={chunk.isFirstBand ? 'pt-2' : ''}>
          {chunk.isFirstBand && (
            <SectionHeaderBar
              section={section}
              sectionOrderIndex={chunk.sectionOrderIndex}
              onTitleChange={(t) => onSectionTitleChange(chunk.sectionId, t)}
              onTargetTotalChange={(v) => onSectionTargetTotalChange(chunk.sectionId, v)}
              onEnableAutoScore={() => onEnableAutoScore(chunk.sectionId)}
              onSwapSections={handleSwapSections}
              readOnlyPreview={readOnlyPreview}
            />
          )}

          <QuestionBandView
            band={chunk.band}
            columnsPerRow={exam.columnsPerRow}
            placeholder={placeholder}
            focusedQuestionId={focusedQuestionId}
            onFocusHandled={onFocusHandled}
            onQuestionTextChange={(qId, text) => onQuestionTextChange(chunk.sectionId, qId, text)}
            onQuestionScoreChange={(qId, score) =>
              onQuestionScoreChange(chunk.sectionId, qId, score)
            }
            onDeleteQuestion={(qId) => onDeleteQuestion(chunk.sectionId, qId)}
            onEnterSubmit={() => onAddQuestion(chunk.sectionId)}
            readOnlyPreview={readOnlyPreview}
          />

          {chunk.isLastBand &&
            (readOnlyPreview ? (
              <div className="h-[36px]" />
            ) : (
              renderSectionAddButton(chunk.sectionId)
            ))}
        </div>
      );

      if (chunk.isFirstBand && !readOnlyPreview) {
        return (
          <SortableSectionStarter
            sectionId={chunk.sectionId}
            isActiveDropTarget={
              activeDragSection !== null && activeDragSection !== chunk.sectionId
            }
          >
            {({ dragHandleProps, setActivatorRef }) => (
              <div className="pt-2">
                <SectionHeaderBar
                  section={section}
                  sectionOrderIndex={chunk.sectionOrderIndex}
                  onTitleChange={(t) => onSectionTitleChange(chunk.sectionId, t)}
                  onTargetTotalChange={(v) => onSectionTargetTotalChange(chunk.sectionId, v)}
                  onEnableAutoScore={() => onEnableAutoScore(chunk.sectionId)}
                  onSwapSections={handleSwapSections}
                  dragHandleProps={dragHandleProps}
                  setDragActivatorRef={setActivatorRef}
                />

                <QuestionBandView
                  band={chunk.band}
                  columnsPerRow={exam.columnsPerRow}
                  placeholder={placeholder}
                  focusedQuestionId={focusedQuestionId}
                  onFocusHandled={onFocusHandled}
                  onQuestionTextChange={(qId, text) =>
                    onQuestionTextChange(chunk.sectionId, qId, text)
                  }
                  onQuestionScoreChange={(qId, score) =>
                    onQuestionScoreChange(chunk.sectionId, qId, score)
                  }
                  onDeleteQuestion={(qId) => onDeleteQuestion(chunk.sectionId, qId)}
                  onEnterSubmit={() => onAddQuestion(chunk.sectionId)}
                />

                {chunk.isLastBand && renderSectionAddButton(chunk.sectionId)}
              </div>
            )}
          </SortableSectionStarter>
        );
      }

      return bandContent;
    }

    // Blank Block
    return (
      <BlankBlockView
        blankId={chunk.blankId}
        onDelete={onDeleteBlankBlock}
        readOnlyPreview={readOnlyPreview}
      />
    );
  };

  const activeSectionData = activeDragSection ? exam.sections[activeDragSection] : null;
  const activeSectionIdx = activeDragSection ? exam.sectionOrder.indexOf(activeDragSection) : 0;

  return (
    <div className="relative py-6 sm:py-8 px-4 flex flex-col items-center overflow-x-auto">
      {/* Offscreen Measurement Mirror matching exact A4 usable width (674px) */}
      <div
        aria-hidden="true"
        className="fixed -left-[9999px] top-0 w-[674px] pointer-events-none opacity-0 font-exam"
      >
        {chunks.map((chunk) => (
          <div
            key={chunk.key}
            ref={(el) => {
              measureRefs.current[chunk.key] = el;
            }}
          >
            {renderChunk(chunk, true)}
          </div>
        ))}
      </div>

      {/* Main Interactive A4 Pages Stack */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        onDragCancel={() => setActiveDragSection(null)}
      >
        <SortableContext items={exam.sectionOrder} strategy={verticalListSortingStrategy}>
          <div className="exam-workspace flex flex-col items-center gap-7">
            {pages.map((pageChunks, pageIndex) => (
              <section
                key={`page_${pageIndex}`}
                aria-label={`考卷第 ${pageIndex + 1} 頁`}
                className="exam-page relative w-[794px] h-[1123px] bg-white text-slate-950 font-exam shadow-[0_6px_28px_rgba(15,23,42,0.08)] border border-slate-200/90 px-[60px] pt-[56px] pb-[52px] flex flex-col justify-between shrink-0"
              >
                <div className="flex flex-col gap-3">
                  {pageChunks.map((chunk) => (
                    <div key={chunk.key}>{renderChunk(chunk, false)}</div>
                  ))}
                </div>

                {/* Page Number Footer */}
                <footer className="text-center text-[11.5px] text-slate-500 tabular-nums pt-2 select-none">
                  第 {pageIndex + 1} 頁 / 共 {pages.length} 頁
                </footer>
              </section>
            ))}
          </div>
        </SortableContext>

        <DragOverlay>
          {activeSectionData ? (
            <div className="bg-white border-2 border-blue-600 shadow-xl rounded-lg px-4 py-3 flex items-center gap-2.5 text-sm font-semibold text-slate-900">
              <GripVertical className="w-4 h-4 text-blue-600" />
              <span>
                移動區塊：{getChineseSectionNumeral(activeSectionIdx)}、{activeSectionData.title}
              </span>
              <span className="text-xs font-normal text-slate-500 tabular-nums">
                （共 {activeSectionData.questions.length} 題）
              </span>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>

      {/* Bottom Blank Section Control (always below all formal question sections) */}
      <div className="print:hidden w-[794px] mt-6 flex flex-col items-center gap-2">
        <button
          type="button"
          onClick={onAddBlankBlock}
          className="w-full py-3.5 px-4 bg-white/80 hover:bg-white border-2 border-dashed border-slate-300 hover:border-blue-500 text-slate-700 hover:text-blue-700 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          加入留白區塊（手寫或自行設計題目用空白區）
        </button>
      </div>
    </div>
  );
};

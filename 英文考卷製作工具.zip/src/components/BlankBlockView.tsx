import { Trash2 } from 'lucide-react';
import React from 'react';

interface BlankBlockViewProps {
  blankId: string;
  onDelete: (id: string) => void;
  readOnlyPreview?: boolean;
}

export const BlankBlockView: React.FC<BlankBlockViewProps> = ({
  blankId,
  onDelete,
  readOnlyPreview = false,
}) => {
  if (readOnlyPreview) {
    return <div className="h-[158px] w-full" aria-hidden="true" />;
  }

  return (
    <div className="group/blank relative h-[158px] w-full rounded-md border border-dashed border-slate-300/90 print:border-transparent transition-colors hover:border-slate-400">
      <div className="print:hidden absolute top-2 right-2 flex items-center gap-2">
        <button
          type="button"
          onClick={() => onDelete(blankId)}
          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 bg-white border border-slate-200 hover:text-rose-600 hover:border-rose-200 hover:bg-rose-50 rounded-md shadow-xs transition-colors cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
          刪除留白區塊
        </button>
      </div>
    </div>
  );
};

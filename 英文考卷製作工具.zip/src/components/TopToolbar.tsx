import { Columns2, Columns3, Download, FileDown, FileText, Loader2, Printer, RotateCcw } from 'lucide-react';
import React from 'react';

interface TopToolbarProps {
  pageCount: number;
  zhCount: number;
  enCount: number;
  columnsPerRow: 2 | 3;
  onColumnsChange: (cols: 2 | 3) => void;
  onResetExam: () => void;
  onPrint: () => void;
  onDownloadStandalone: () => void;
  onExportWord: () => void;
  onExportPdf: () => void;
  isDownloadingStandalone: boolean;
  isExportingWord: boolean;
  isExportingPdf: boolean;
}

export const TopToolbar: React.FC<TopToolbarProps> = ({
  pageCount,
  zhCount,
  enCount,
  columnsPerRow,
  onColumnsChange,
  onResetExam,
  onPrint,
  onDownloadStandalone,
  onExportWord,
  onExportPdf,
  isDownloadingStandalone,
  isExportingWord,
  isExportingPdf,
}) => {
  return (
    <header className="print:hidden sticky top-0 z-30 bg-white border-b border-slate-200">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Brand Title */}
        <div className="flex items-center shrink-0">
          <h1 className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
            英文考卷製作工具
          </h1>
        </div>

        {/* Zone 2: Unboxed Live Metadata & Compact Layout Selector */}
        <div className="hidden lg:flex items-center gap-6 min-w-0">
          <div className="flex items-center gap-2 text-xs text-slate-500 tabular-nums whitespace-nowrap">
            <span>A4 直式</span>
            <span aria-hidden="true">·</span>
            <span>共 {pageCount} 頁</span>
            <span aria-hidden="true">·</span>
            <span>中翻英 {zhCount} 題</span>
            <span aria-hidden="true">·</span>
            <span>英翻中 {enCount} 題</span>
          </div>

          <div className="h-4 w-px bg-slate-200" aria-hidden="true" />

          {/* Column density control (each column strictly holds 5 vertical questions) */}
          <div
            className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg"
            role="group"
            aria-label="每列欄數"
          >
            <button
              type="button"
              onClick={() => onColumnsChange(2)}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                columnsPerRow === 2
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Columns2 className="w-3.5 h-3.5" />
              每列 2 欄
            </button>
            <button
              type="button"
              onClick={() => onColumnsChange(3)}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                columnsPerRow === 3
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Columns3 className="w-3.5 h-3.5" />
              每列 3 欄
            </button>
          </div>
        </div>

        {/* Zone 3: Export & Print Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onResetExam}
            title="重設為預設範例"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            重設範例
          </button>

          <button
            type="button"
            onClick={onDownloadStandalone}
            disabled={isDownloadingStandalone}
            title="下載可獨立雙擊開啟的單一 HTML 檔案"
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isDownloadingStandalone ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Download className="w-3.5 h-3.5 text-slate-600" />
            )}
            下載單檔
          </button>

          <button
            type="button"
            onClick={onPrint}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            列印
          </button>

          <button
            type="button"
            onClick={onExportWord}
            disabled={isExportingWord}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isExportingWord ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <FileText className="w-3.5 h-3.5 text-blue-700" />
            )}
            匯出 Word
          </button>

          <button
            type="button"
            onClick={onExportPdf}
            disabled={isExportingPdf}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {isExportingPdf ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <FileDown className="w-3.5 h-3.5" />
            )}
            匯出 PDF
          </button>
        </div>
      </div>

      {/* Compact mobile/tablet metadata & column toggle row */}
      <div className="lg:hidden border-t border-slate-100 px-4 py-2 flex items-center justify-between gap-3 bg-slate-50/70">
        <div className="text-xs text-slate-500 tabular-nums truncate">
          A4 直式 · 共 {pageCount} 頁 · 中翻英 {zhCount} 題 · 英翻中 {enCount} 題
        </div>
        <div className="flex items-center gap-1 p-0.5 bg-slate-200/70 rounded-md shrink-0">
          <button
            type="button"
            onClick={() => onColumnsChange(2)}
            className={`px-2 py-0.5 text-xs font-medium rounded ${
              columnsPerRow === 2 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            2 欄
          </button>
          <button
            type="button"
            onClick={() => onColumnsChange(3)}
            className={`px-2 py-0.5 text-xs font-medium rounded ${
              columnsPerRow === 3 ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
            }`}
          >
            3 欄
          </button>
        </div>
      </div>
    </header>
  );
};

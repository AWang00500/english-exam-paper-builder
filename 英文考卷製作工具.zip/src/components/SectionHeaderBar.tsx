import { ArrowUpDown, GripVertical, RotateCcw } from 'lucide-react';
import React from 'react';
import { QuestionSectionData } from '../types/exam';
import { formatScore, getChineseSectionNumeral, getSectionSumScore } from '../utils/scoring';

interface SectionHeaderBarProps {
  section: QuestionSectionData;
  sectionOrderIndex: number;
  onTitleChange: (title: string) => void;
  onTargetTotalChange: (total: number) => void;
  onEnableAutoScore: () => void;
  onSwapSections: () => void;
  dragHandleProps?: Record<string, unknown>;
  setDragActivatorRef?: (element: HTMLElement | null) => void;
  readOnlyPreview?: boolean;
}

export const SectionHeaderBar: React.FC<SectionHeaderBarProps> = ({
  section,
  sectionOrderIndex,
  onTitleChange,
  onTargetTotalChange,
  onEnableAutoScore,
  onSwapSections,
  dragHandleProps,
  setDragActivatorRef,
  readOnlyPreview = false,
}) => {
  const numeral = getChineseSectionNumeral(sectionOrderIndex);
  const count = section.questions.length;
  const actualSum = getSectionSumScore(section);

  const firstScore = count > 0 ? section.questions[0].score : 0;
  const allEqual = count > 0 && section.questions.every((q) => Math.abs(q.score - firstScore) < 0.001);

  const printedSummary =
    count === 0
      ? '（共 0 題，總分 0 分）'
      : allEqual
        ? `（共 ${count} 題，每題 ${formatScore(firstScore)} 分，總分 ${formatScore(actualSum)} 分）`
        : `（共 ${count} 題，總分 ${formatScore(actualSum)} 分）`;

  if (readOnlyPreview) {
    return (
      <div className="flex flex-wrap items-baseline justify-between gap-2 pb-2">
        <div className="flex items-baseline gap-1.5">
          <span className="text-[16px] font-bold text-slate-950">
            {numeral}、{section.title || (section.id === 'zhToEn' ? '中翻英' : '英翻中')}
          </span>
          <span className="text-[12.5px] text-slate-700 tabular-nums">{printedSummary}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5">
      {/* Left: Section Drag Handle + Numbering + Editable Title + Printed Summary */}
      <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
        <button
          type="button"
          ref={setDragActivatorRef}
          {...(dragHandleProps || {})}
          title="拖曳整個區塊調整上下順序"
          className="print:hidden inline-flex items-center gap-0.5 px-1.5 py-1 -ml-1.5 text-slate-400 hover:text-blue-700 hover:bg-blue-50 rounded cursor-grab active:cursor-grabbing transition-colors"
        >
          <GripVertical className="w-4 h-4" />
        </button>

        <span className="text-[16px] font-bold text-slate-950 shrink-0">{numeral}、</span>

        <input
          type="text"
          value={section.title}
          onChange={(e) => onTitleChange(e.target.value)}
          placeholder={section.id === 'zhToEn' ? '中翻英' : '英翻中'}
          aria-label="區塊標題"
          className="w-28 sm:w-36 bg-transparent text-[16px] font-bold text-slate-950 border-b border-transparent hover:border-slate-300 focus:border-blue-600 focus:outline-none py-0.5 print-clean-input"
        />

        <span className="text-[12.5px] text-slate-700 tabular-nums whitespace-nowrap">
          {printedSummary}
        </span>
      </div>

      {/* Right: Independent Section Scoring Control & Quick Swap (hidden when printing) */}
      <div className="print:hidden flex items-center gap-2 text-xs shrink-0">
        {section.isAutoScore ? (
          <div className="flex items-center gap-1.5 bg-slate-100 px-2 py-1 rounded-md text-slate-700">
            <span className="font-medium text-blue-800 whitespace-nowrap">自動平均</span>
            <span className="text-slate-400">·</span>
            <label className="flex items-center gap-1 whitespace-nowrap">
              <span>總分</span>
              <input
                type="number"
                min={0}
                step="any"
                value={section.targetTotalScore}
                onChange={(e) => onTargetTotalChange(parseFloat(e.target.value) || 0)}
                aria-label={`${section.title} 預設總分`}
                className="w-12 px-1 py-0.5 text-center font-mono font-semibold tabular-nums bg-white border border-slate-300 rounded focus:border-blue-600 focus:outline-none"
              />
              <span>分</span>
            </label>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 bg-amber-50 border border-amber-200/80 px-2 py-1 rounded-md text-amber-900">
            <span className="font-medium whitespace-nowrap">手動配分</span>
            <span className="text-amber-400">·</span>
            <span className="font-mono tabular-nums whitespace-nowrap">
              合計 {formatScore(actualSum)} 分
            </span>
            <button
              type="button"
              onClick={onEnableAutoScore}
              title="恢復自動平均配分"
              className="inline-flex items-center gap-1 ml-1 px-1.5 py-0.5 text-[11px] font-medium text-blue-700 bg-white border border-blue-200 hover:bg-blue-50 rounded transition-colors cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-3 h-3" />
              恢復自動平均
            </button>
          </div>
        )}

        <button
          type="button"
          onClick={onSwapSections}
          title="交換兩大題上下順序"
          className="inline-flex items-center gap-1 px-2 py-1 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer whitespace-nowrap"
        >
          <ArrowUpDown className="w-3.5 h-3.5" />
          對調
        </button>
      </div>
    </div>
  );
};

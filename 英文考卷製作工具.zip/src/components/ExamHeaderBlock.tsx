import {
  closestCenter,
  DndContext,
  DragEndEvent,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import {
  arrayMove,
  horizontalListSortingStrategy,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  ArrowUpDown,
  GripVertical,
  Plus,
  X,
} from 'lucide-react';
import React from 'react';
import { BasicInfoField, ExamHeaderData, HeaderSubBlockId, TextAlign } from '../types/exam';

interface ExamHeaderBlockProps {
  header: ExamHeaderData;
  onChange: (next: ExamHeaderData) => void;
  onAddInfoField: () => void;
  readOnlyPreview?: boolean;
}

interface SortableInfoItemProps {
  field: BasicInfoField;
  infoAlign: TextAlign;
  canDelete: boolean;
  onUpdate: (text: string) => void;
  onDelete: () => void;
  readOnlyPreview?: boolean;
}

const SortableInfoItem: React.FC<SortableInfoItemProps> = ({
  field,
  infoAlign,
  canDelete,
  onUpdate,
  onDelete,
  readOnlyPreview,
}) => {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: field.id,
  });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const alignClass =
    infoAlign === 'left' ? 'text-left' : infoAlign === 'right' ? 'text-right' : 'text-center';

  if (readOnlyPreview) {
    return <div className={`text-[13.5px] text-slate-900 ${alignClass}`}>{field.text}</div>;
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`group/field relative flex items-center gap-0.5 rounded px-1 py-0.5 transition-colors ${
        isDragging ? 'bg-blue-50 ring-1 ring-blue-400 z-10' : 'hover:bg-slate-50 print:hover:bg-transparent'
      }`}
    >
      <button
        type="button"
        {...attributes}
        {...listeners}
        title="拖曳調整此欄位順序"
        className="print:hidden opacity-0 group-hover/field:opacity-100 focus:opacity-100 text-slate-400 hover:text-slate-700 cursor-grab active:cursor-grabbing shrink-0 p-0.5 transition-opacity"
      >
        <GripVertical className="w-3 h-3" />
      </button>

      <input
        type="text"
        value={field.text}
        onChange={(e) => onUpdate(e.target.value)}
        aria-label="基本資料欄位"
        className={`w-full min-w-[60px] bg-transparent text-[13.5px] text-slate-950 font-normal border-b border-transparent hover:border-slate-300 focus:border-blue-600 focus:outline-none py-0.5 print-clean-input ${alignClass}`}
      />

      {canDelete && (
        <button
          type="button"
          onClick={onDelete}
          title="移除此欄位"
          className="print:hidden opacity-0 group-hover/field:opacity-100 focus:opacity-100 text-slate-400 hover:text-rose-600 shrink-0 p-0.5 transition-opacity cursor-pointer"
        >
          <X className="w-3 h-3" />
        </button>
      )}
    </div>
  );
};

interface SortableSubBlockWrapperProps {
  id: HeaderSubBlockId;
  label: string;
  align: TextAlign;
  onAlignChange: (align: TextAlign) => void;
  onSwapOrder: () => void;
  extraAction?: React.ReactNode;
  readOnlyPreview?: boolean;
  children: React.ReactNode;
}

const SortableSubBlockWrapper: React.FC<SortableSubBlockWrapperProps> = ({
  id,
  label,
  align,
  onAlignChange,
  onSwapOrder,
  extraAction,
  readOnlyPreview,
  children,
}) => {
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, transform, transition, isDragging } =
    useSortable({ id });

  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  if (readOnlyPreview) {
    return <div>{children}</div>;
  }

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`group/sub relative rounded-md transition-all ${
        isDragging
          ? 'bg-blue-50/70 ring-2 ring-blue-500 shadow-sm z-20'
          : 'hover:ring-1 hover:ring-slate-200 print:hover:ring-0'
      }`}
    >
      {/* Floating inline controls on hover/focus (hidden when printing) */}
      <div className="print:hidden opacity-0 group-hover/sub:opacity-100 focus-within:opacity-100 transition-opacity flex items-center gap-1 absolute -top-7 right-0 bg-white border border-slate-200 shadow-xs rounded-md px-1.5 py-0.5 z-20">
        <button
          type="button"
          ref={setActivatorNodeRef}
          {...attributes}
          {...listeners}
          title={`拖曳調整「${label}」上下位置`}
          className="flex items-center gap-1 text-[11px] font-medium text-slate-600 hover:text-blue-700 cursor-grab active:cursor-grabbing px-1 py-0.5"
        >
          <GripVertical className="w-3.5 h-3.5" />
          <span>拖曳{label}</span>
        </button>

        <span className="w-px h-3 bg-slate-200" />

        <button
          type="button"
          onClick={onSwapOrder}
          title="交換標題與基本資料上下順序"
          className="p-0.5 text-slate-500 hover:text-slate-900 rounded cursor-pointer"
        >
          <ArrowUpDown className="w-3 h-3" />
        </button>

        <span className="w-px h-3 bg-slate-200" />

        <button
          type="button"
          onClick={() => onAlignChange('left')}
          title="靠左對齊"
          className={`p-0.5 rounded cursor-pointer ${
            align === 'left' ? 'text-blue-700 bg-blue-50' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <AlignLeft className="w-3 h-3" />
        </button>
        <button
          type="button"
          onClick={() => onAlignChange('center')}
          title="置中對齊"
          className={`p-0.5 rounded cursor-pointer ${
            align === 'center' ? 'text-blue-700 bg-blue-50' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <AlignCenter className="w-3 h-3" />
        </button>
        <button
          type="button"
          onClick={() => onAlignChange('right')}
          title="靠右對齊"
          className={`p-0.5 rounded cursor-pointer ${
            align === 'right' ? 'text-blue-700 bg-blue-50' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <AlignRight className="w-3 h-3" />
        </button>

        {extraAction}
      </div>

      {children}
    </div>
  );
};

export const ExamHeaderBlock: React.FC<ExamHeaderBlockProps> = ({
  header,
  onChange,
  onAddInfoField,
  readOnlyPreview = false,
}) => {
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const handleSubBlockDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = header.order.indexOf(active.id as HeaderSubBlockId);
    const newIndex = header.order.indexOf(over.id as HeaderSubBlockId);
    if (oldIndex === -1 || newIndex === -1) return;
    onChange({
      ...header,
      order: arrayMove(header.order, oldIndex, newIndex),
    });
  };

  const handleInfoFieldDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = header.infoFields.findIndex((f) => f.id === active.id);
    const newIndex = header.infoFields.findIndex((f) => f.id === over.id);
    if (oldIndex === -1 || newIndex === -1) return;
    onChange({
      ...header,
      infoFields: arrayMove(header.infoFields, oldIndex, newIndex),
    });
  };

  const swapHeaderOrder = () => {
    onChange({
      ...header,
      order: [header.order[1], header.order[0]],
    });
  };

  const titleAlignClass =
    header.titleAlign === 'left'
      ? 'text-left'
      : header.titleAlign === 'right'
        ? 'text-right'
        : 'text-center';

  const renderSubBlock = (subId: HeaderSubBlockId) => {
    if (subId === 'title') {
      return (
        <SortableSubBlockWrapper
          key="title"
          id="title"
          label="標題"
          align={header.titleAlign}
          onAlignChange={(align) => onChange({ ...header, titleAlign: align })}
          onSwapOrder={swapHeaderOrder}
          readOnlyPreview={readOnlyPreview}
        >
          <div className="py-1 px-1">
            {readOnlyPreview ? (
              <div className={`text-[24px] font-bold tracking-wide text-slate-950 ${titleAlignClass}`}>
                {header.title || '英文單字測驗'}
              </div>
            ) : (
              <input
                type="text"
                value={header.title}
                onChange={(e) => onChange({ ...header, title: e.target.value })}
                placeholder="輸入考卷總標題"
                aria-label="考卷總標題"
                className={`w-full bg-transparent text-[24px] font-bold tracking-wide text-slate-950 border-b border-transparent hover:border-slate-300 focus:border-blue-600 focus:outline-none py-0.5 print-clean-input ${titleAlignClass}`}
              />
            )}
          </div>
        </SortableSubBlockWrapper>
      );
    }

    return (
      <SortableSubBlockWrapper
        key="info"
        id="info"
        label="基本資料區"
        align={header.infoAlign}
        onAlignChange={(align) => onChange({ ...header, infoAlign: align })}
        onSwapOrder={swapHeaderOrder}
        readOnlyPreview={readOnlyPreview}
        extraAction={
          <>
            <span className="w-px h-3 bg-slate-200" />
            <button
              type="button"
              onClick={onAddInfoField}
              title="新增基本資料欄位"
              className="flex items-center gap-0.5 text-[11px] font-medium text-blue-700 hover:text-blue-800 px-1 py-0.5 cursor-pointer"
            >
              <Plus className="w-3 h-3" />
              欄位
            </button>
          </>
        }
      >
        <div className="py-1 px-1">
          {readOnlyPreview ? (
            <div
              className="grid gap-3"
              style={{
                gridTemplateColumns: `repeat(${Math.max(header.infoFields.length, 1)}, minmax(0, 1fr))`,
              }}
            >
              {header.infoFields.map((field) => (
                <SortableInfoItem
                  key={field.id}
                  field={field}
                  infoAlign={header.infoAlign}
                  canDelete={false}
                  onUpdate={() => {}}
                  onDelete={() => {}}
                  readOnlyPreview
                />
              ))}
            </div>
          ) : (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleInfoFieldDragEnd}
            >
              <SortableContext
                items={header.infoFields.map((f) => f.id)}
                strategy={horizontalListSortingStrategy}
              >
                <div
                  className="grid gap-2"
                  style={{
                    gridTemplateColumns: `repeat(${Math.max(header.infoFields.length, 1)}, minmax(0, 1fr))`,
                  }}
                >
                  {header.infoFields.map((field) => (
                    <SortableInfoItem
                      key={field.id}
                      field={field}
                      infoAlign={header.infoAlign}
                      canDelete={header.infoFields.length > 1}
                      onUpdate={(text) =>
                        onChange({
                          ...header,
                          infoFields: header.infoFields.map((f) =>
                            f.id === field.id ? { ...f, text } : f
                          ),
                        })
                      }
                      onDelete={() =>
                        onChange({
                          ...header,
                          infoFields: header.infoFields.filter((f) => f.id !== field.id),
                        })
                      }
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          )}
        </div>
      </SortableSubBlockWrapper>
    );
  };

  return (
    <div className="pb-3 mb-2 border-b-2 border-slate-900 space-y-2">
      {readOnlyPreview ? (
        <div className="space-y-2">{header.order.map((subId) => renderSubBlock(subId))}</div>
      ) : (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleSubBlockDragEnd}
        >
          <SortableContext items={header.order} strategy={verticalListSortingStrategy}>
            <div className="space-y-2">{header.order.map((subId) => renderSubBlock(subId))}</div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  );
};

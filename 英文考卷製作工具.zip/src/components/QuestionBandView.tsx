import { Trash2 } from 'lucide-react';
import React from 'react';
import { QuestionBand } from '../utils/pagination';
import { formatScore } from '../utils/scoring';

interface QuestionBandViewProps {
  band: QuestionBand;
  columnsPerRow: 2 | 3;
  placeholder: string;
  focusedQuestionId: string | null;
  onFocusHandled: () => void;
  onQuestionTextChange: (questionId: string, text: string) => void;
  onQuestionScoreChange: (questionId: string, score: number) => void;
  onDeleteQuestion: (questionId: string) => void;
  onEnterSubmit: () => void;
  readOnlyPreview?: boolean;
}

export const QuestionBandView: React.FC<QuestionBandViewProps> = ({
  band,
  columnsPerRow,
  placeholder,
  focusedQuestionId,
  onFocusHandled,
  onQuestionTextChange,
  onQuestionScoreChange,
  onDeleteQuestion,
  onEnterSubmit,
  readOnlyPreview = false,
}) => {
  return (
    <div
      className="grid gap-x-5 items-start py-1"
      style={{
        gridTemplateColumns: `repeat(${columnsPerRow}, minmax(0, 1fr))`,
      }}
    >
      {band.columns.map((column, colIdx) => (
        <div key={colIdx} className="flex flex-col gap-2.5 min-w-0">
          {column.map(({ question, number }) => {
            if (readOnlyPreview) {
              return (
                <div
                  key={question.id}
                  className="flex items-baseline flex-wrap gap-x-1 gap-y-0.5 text-[14px] leading-snug text-slate-950"
                >
                  <span className="font-semibold tabular-nums shrink-0">{number}.</span>
                  <span className="break-words">{question.text || '________'}：</span>
                  <span
                    className="inline-block w-[112px] shrink-0 border-b border-slate-950 h-[1.15em]"
                    aria-hidden="true"
                  />
                  <span className="text-[11.5px] text-slate-600 tabular-nums shrink-0">
                    ({formatScore(question.score)}分)
                  </span>
                </div>
              );
            }

            return (
              <div
                key={question.id}
                className="group/q flex items-center gap-1 text-[14px] leading-snug text-slate-950 rounded px-1 -mx-1 py-0.5 hover:bg-slate-50/90 print:hover:bg-transparent transition-colors"
              >
                {/* Sequential auto-number */}
                <span className="font-semibold tabular-nums shrink-0 w-5 text-right pr-0.5">
                  {number}.
                </span>

                {/* Directly editable question text */}
                <input
                  type="text"
                  value={question.text}
                  placeholder={placeholder}
                  aria-label={`第 ${number} 題題目`}
                  ref={(el) => {
                    if (el && focusedQuestionId === question.id) {
                      el.focus();
                      onFocusHandled();
                    }
                  }}
                  onChange={(e) => onQuestionTextChange(question.id, e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.nativeEvent.isComposing) {
                      e.preventDefault();
                      onEnterSubmit();
                    }
                  }}
                  className="min-w-[54px] flex-1 bg-transparent text-[14px] text-slate-950 placeholder:text-slate-300 border-b border-transparent hover:border-slate-300 focus:border-blue-600 focus:outline-none py-0.5 print-clean-input"
                />

                <span className="shrink-0 select-none">：</span>

                {/* Fixed uniform answer blank (sufficient for 10+ handwritten English letters) */}
                <span
                  className="inline-block w-[112px] shrink-0 border-b border-slate-950 h-[1.15em]"
                  aria-hidden="true"
                />

                {/* Directly editable per-question score */}
                <label className="inline-flex items-center shrink-0 text-[11.5px] text-slate-600 tabular-nums">
                  <span>(</span>
                  <input
                    type="number"
                    min={0}
                    step="any"
                    value={question.score}
                    onChange={(e) => {
                      const parsed = parseFloat(e.target.value);
                      onQuestionScoreChange(question.id, Number.isNaN(parsed) ? 0 : parsed);
                    }}
                    aria-label={`第 ${number} 題配分`}
                    className="w-8 text-center bg-transparent font-mono tabular-nums text-slate-800 border-b border-transparent hover:border-slate-300 focus:border-blue-600 focus:bg-white focus:outline-none print-clean-input"
                  />
                  <span>分)</span>
                </label>

                {/* Small trash icon to delete question */}
                <button
                  type="button"
                  onClick={() => onDeleteQuestion(question.id)}
                  title="刪除此題"
                  aria-label={`刪除第 ${number} 題`}
                  className="print:hidden opacity-40 group-hover/q:opacity-100 focus:opacity-100 text-slate-400 hover:text-rose-600 p-1 rounded transition-opacity shrink-0 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
};
